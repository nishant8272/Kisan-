import joblib
from sklearn.metrics.pairwise import cosine_similarity

# Load your saved model
obj = joblib.load("farmer_qa_retrieval_joblib.pkl")
vectorizer = obj["vectorizer"]
train_questions = obj["train_questions"]
train_answers = obj["train_answers"]
X_train_tfidf = obj["X_train_tfidf"]

def farmer_chatbot(user_question, top_k=1):
    q_tfidf = vectorizer.transform([user_question])
    sims = cosine_similarity(q_tfidf, X_train_tfidf)[0]
    top_idx = sims.argsort()[::-1][:top_k]
    
    best_idx = top_idx[0]
    best_answer = train_answers[best_idx]
    best_score = sims[best_idx]

    return f"👨‍🌾 Farmer Question: {user_question}\n🤖 Assistant Answer: {best_answer} (confidence: {best_score:.2f})"

while True:
    query = input("Ask your question (or type 'exit'): ")
    if query.lower() in ["exit", "quit", "bye"]:
        print("👋 Goodbye! Take care of your crops.")
        break
    print(farmer_chatbot(query))
