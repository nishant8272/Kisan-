# filename = backend.py
from flask import Flask, request, jsonify
import joblib
from sklearn.metrics.pairwise import cosine_similarity

# Model load karo
obj = joblib.load("./chatbot/farmer_qa_retrieval_joblib.pkl")
vectorizer = obj["vectorizer"]
train_answers = obj["train_answers"]
X_train_tfidf = obj["X_train_tfidf"]

def farmer_chatbot(user_question, top_k=1):
    q_tfidf = vectorizer.transform([user_question])
    sims = cosine_similarity(q_tfidf, X_train_tfidf)[0]
    top_idx = sims.argsort()[::-1][:top_k]

    best_idx = top_idx[0]
    best_answer = train_answers[best_idx]
    best_score = sims[best_idx]

    return {"answer": best_answer, "confidence": round(float(best_score), 2)}

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_question = data.get("query", "")
    return jsonify(farmer_chatbot(user_question))

# CORRECTED: Use double underscores for __name__ and "__main__"
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)