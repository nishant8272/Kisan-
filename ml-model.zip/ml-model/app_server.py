from flask import Flask, request, jsonify
from tensorflow.keras.models import load_model
import joblib
import numpy as np
from PIL import Image
import io
import os
from sklearn.metrics.pairwise import cosine_similarity # 🤖 Added for chatbot

# --- PATHS ---
DISEASE_MODEL_PATH = "Image_model/models/disease_model.h5"
CLASS_NAMES_PATH = "Image_model/models/class_names.npy"
CROP_MODEL_PATH = "crop_recommendation/crop_model.pkl"
CROP_LABEL_PATH = "crop_recommendation/label_encoder.pkl"
CHATBOT_MODEL_PATH = "chatbot/farmer_qa_retrieval_joblib.pkl" # 🤖 Chatbot model path

# --- LOAD MODELS SAFELY ---
# Disease and Crop models
disease_model = None
class_names = None
crop_model = None
crop_labels = None

# 🤖 Chatbot model components
vectorizer = None
train_answers = None
X_train_tfidf = None

# Load Disease Model
if os.path.exists(DISEASE_MODEL_PATH):
    disease_model = load_model(DISEASE_MODEL_PATH)
    class_names = np.load(CLASS_NAMES_PATH, allow_pickle=True)
else:
    print(f"⚠️ Disease model not found at {DISEASE_MODEL_PATH}")

# Load Crop Recommendation Model
if os.path.exists(CROP_MODEL_PATH):
    crop_model = joblib.load(CROP_MODEL_PATH)
else:
    print(f"⚠️ Crop recommendation model not found at {CROP_MODEL_PATH}")

# Load Crop Labels
if os.path.exists(CROP_LABEL_PATH):
    crop_labels = joblib.load(CROP_LABEL_PATH)
else:
    print(f"⚠️ Crop label mapping not found at {CROP_LABEL_PATH}")
    
# 🤖 Load Chatbot Model
if os.path.exists(CHATBOT_MODEL_PATH):
    try:
        chatbot_obj = joblib.load(CHATBOT_MODEL_PATH)
        vectorizer = chatbot_obj["vectorizer"]
        train_answers = chatbot_obj["train_answers"]
        X_train_tfidf = chatbot_obj["X_train_tfidf"]
        print("✅ Chatbot model loaded successfully.")
    except Exception as e:
        print(f"⚠️ Error loading chatbot model: {e}")
else:
    print(f"⚠️ Chatbot model not found at {CHATBOT_MODEL_PATH}")


TARGET_SIZE = (160, 160)

app = Flask(__name__)

# --- HELPER FUNCTIONS ---

# 🤖 Chatbot helper function
def farmer_chatbot(user_question, top_k=1):
    q_tfidf = vectorizer.transform([user_question])
    sims = cosine_similarity(q_tfidf, X_train_tfidf)[0]
    top_idx = sims.argsort()[::-1][:top_k]

    best_idx = top_idx[0]
    best_answer = train_answers[best_idx]
    best_score = sims[best_idx]

    return {"answer": best_answer, "confidence": round(float(best_score), 2)}


# --- API ROUTES ---

@app.route('/', methods=['GET'])
def health():
    """Health check endpoint."""
    return "Model prediction API is running."

# 🌱 Crop recommendation
@app.route('/predict_crop', methods=['POST'])
def predict_crop():
    """Predicts the best crop based on environmental factors."""
    if crop_model is None or crop_labels is None:
        return jsonify({"error": "Crop model or labels not loaded"}), 500
    
    try:
        data = request.json
        features = [
            data['N'], data['P'], data['K'], data['temperature'],
            data['humidity'], data['ph'], data['rainfall']
        ]
        pred_idx = crop_model.predict([features])[0]

        if hasattr(crop_labels, "inverse_transform"):
            crop_name = crop_labels.inverse_transform([pred_idx])[0]
        else:
            crop_name = crop_labels[pred_idx]

        return jsonify({'recommended_crop': str(crop_name)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# 🌿 Disease prediction
@app.route('/predict_disease', methods=['POST'])
def predict_disease():
    """Predicts plant disease from an image."""
    if disease_model is None or class_names is None:
        return jsonify({"error": "Disease model not loaded"}), 500
    
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    
    try:
        file = request.files["file"]
        img = Image.open(io.BytesIO(file.read())).convert('RGB').resize(TARGET_SIZE)
        arr = np.array(img, dtype=np.float32) / 255.0
        arr = arr[np.newaxis, ...]
        probs = disease_model.predict(arr)
        pred_idx = np.argmax(probs)
        pred_class = class_names[pred_idx]
        return jsonify({
            "predicted_class": str(pred_class),
            "confidence": float(np.max(probs))
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# 🤖 Chatbot route
@app.route("/chat", methods=["POST"])
def chat():
    """Provides an answer to a farmer's question."""
    if vectorizer is None:
        return jsonify({"error": "Chatbot model is not available"}), 503
    
    try:
        data = request.json
        user_question = data.get("query", "")
        response = farmer_chatbot(user_question)
        return jsonify(response)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)